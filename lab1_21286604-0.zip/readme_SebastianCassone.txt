Nota:
La ejecución se demora un poquito, para que no se confunda con un error.